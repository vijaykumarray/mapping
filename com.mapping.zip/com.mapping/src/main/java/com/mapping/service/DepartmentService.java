package com.mapping.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mapping.entity.Department;
import com.mapping.repository.DepartmentRepository;
@Service
public class DepartmentService {
	
	
    @Autowired
    private DepartmentRepository departmentRepository;

    public Department saveDepartment(Department department)
	{
    	departmentRepository.save(department);
		
		return department;
		
	}
	
	public List<Department>getAllDepartment()
	{
		List<Department> ListDepartment=new ArrayList<Department>();
		
		departmentRepository.findAll().forEach(l1->ListDepartment.add(l1));
		return ListDepartment;
	}

	
	
	public void deleteDepartment(long depId){
		departmentRepository.deleteById(depId);
		
	}
	
	public void saveUp(Department department) {
		
		departmentRepository.save(department);
	}

	
	}
	





