package com.mapping.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mapping.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

}
